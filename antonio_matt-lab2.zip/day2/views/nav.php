<?php
	/**
	 * Matt Antonio
	 * Class: SSL
	 * Assignment: Lab 2
	 * Date: 12/02/13
	 */
?>


<nav>
	<ul id="main-nav">
		<li><a href="#">Products</a></li>
		<li><a href="#">Register</a></li>
		<li><a href="#">Login</a></li>
		<li><a href="#">Admin</a></li>
		<li><a href="#">XML</a></li>
	</ul>
</nav>
</div><!-- END .wrap -->
</header>