<?php
	/**
	 * Matt Antonio
	 * Class: SSL
	 * Assignment: Lab 2
	 * Date: 12/02/13
	 */

	include "views/header.php";
	include "views/nav.php";
	include "views/body.php";
	include "views/optional.php";
	include "views/footer.php";
	//include "models/Validator.php";
?>