<?php
	/**
	 * Matt Antonio
	 * Class: SSL
	 * Assignment: Lab 1
	 * Date: 11/25/13
	 */

	include "views/header.php";
	include "views/nav.php";
	include "views/body.php";
	include "views/optional.php";
	include "views/footer.php";
?>