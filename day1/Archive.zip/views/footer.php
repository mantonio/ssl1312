<?php
	/**
	 * Matt Antonio
	 * Class: SSL
	 * Assignment: Lab 1
	 * Date: 11/25/13
	 */
?>
	<footer>
		<div class="wrap">
			<ul id="bottom-nav">
				<li><a href="#">Products</a></li>
				<li><a href="#">Register</a></li>
				<li><a href="#">Login</a></li>
				<li><a href="#">Admin</a></li>
				<li><a href="#">XML</a></li>
			</ul>
		</div>
	</footer>
</body>
</html>